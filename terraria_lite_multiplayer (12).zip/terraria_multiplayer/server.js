const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;
const S=30,COLS=80,ROWS=18;
const rooms = new Map();

function makeWorld(){
  const world=Array.from({length:ROWS},()=>Array(COLS).fill(null)); let h=10;
  for(let x=0;x<COLS;x++){
    h+=Math.random()<.25?(Math.random()<.5?-1:1):0;h=Math.max(7,Math.min(12,h));
    for(let y=h;y<ROWS;y++)world[y][x]=y===h?'grass':y<h+4?'dirt':'stone';
    if(Math.random()<.08&&h>7){world[h-1][x]='wood';if(x+1<COLS)world[h-2][x+1]='leaves';if(x+2<COLS)world[h-2][x+2]='leaves';}
  }
  return world;
}
function getRoom(name){if(!rooms.has(name))rooms.set(name,{world:makeWorld(),players:{}});return rooms.get(name)}
function publicPlayers(room){return room.players}
app.use(express.static(path.join(__dirname,'public')));
app.get('/health',(req,res)=>res.json({ok:true,rooms:rooms.size}));

io.on('connection',socket=>{
  socket.on('joinRoom',({name,room:roomName}={})=>{
    const safeRoom=String(roomName||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,24);
    const safeName=String(name||'Pemain').replace(/[<>]/g,'').slice(0,16)||'Pemain';
    if(!safeRoom){socket.emit('notice','Nama room tidak valid.');return}
    if(socket.data.room){const old=rooms.get(socket.data.room);if(old){delete old.players[socket.id];socket.to(socket.data.room).emit('playerLeft',socket.id)}socket.leave(socket.data.room)}
    const r=getRoom(safeRoom);socket.join(safeRoom);socket.data.room=safeRoom;
    r.players[socket.id]={id:socket.id,name:safeName,x:120+Object.keys(r.players).length*35,y:100,face:1,color:'#fbbf24'};
    socket.emit('joined',{room:safeRoom,world:r.world,players:publicPlayers(r)});
    socket.to(safeRoom).emit('state',{room:safeRoom,world:r.world,players:publicPlayers(r)});
  });
  socket.on('move',data=>{
    const roomName=socket.data.room;if(!roomName)return;const r=rooms.get(roomName),p=r?.players[socket.id];if(!p)return;
    p.x=Math.max(0,Math.min(COLS*S-20,Number(data?.x)||0));p.y=Math.max(0,Math.min(ROWS*S-30,Number(data?.y)||0));p.face=data?.face===-1?-1:1;
    socket.to(roomName).emit('playerMoved',p);
  });
  socket.on('block',data=>{
    const roomName=socket.data.room;if(!roomName)return;const r=rooms.get(roomName);if(!r)return;
    const x=Number(data?.x),y=Number(data?.y),type=data?.type;
    if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||x>=COLS||y<0||y>=ROWS)return;
    if(type!==null&&!['grass','dirt','stone','wood','leaves'].includes(type))return;
    r.world[y][x]=type;
    io.to(roomName).emit('blockChanged',{x,y,type});
  });
  socket.on('leaveRoom',()=>{
    const roomName=socket.data.room;if(!roomName)return;const r=rooms.get(roomName);if(r)delete r.players[socket.id];
    socket.leave(roomName);delete socket.data.room;socket.to(roomName).emit('playerLeft',socket.id);
  });
  socket.on('disconnect',()=>{
    const roomName=socket.data.room;if(!roomName)return;const r=rooms.get(roomName);if(r)delete r.players[socket.id];
    socket.to(roomName).emit('playerLeft',socket.id);
    if(r&&Object.keys(r.players).length===0)rooms.delete(roomName);
  });
});
server.listen(PORT,()=>console.log(`Terraria Lite multiplayer server listening on port ${PORT}`));
