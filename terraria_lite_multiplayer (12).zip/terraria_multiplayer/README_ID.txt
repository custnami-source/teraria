TERRARIA LITE MULTIPLAYER — CARA MENJALANKAN

Persyaratan:
- Node.js versi 18 atau lebih baru
- Koneksi internet saat pertama kali memasang dependency

JALANKAN DI KOMPUTER:
1. Ekstrak ZIP ini.
2. Buka terminal / Command Prompt di folder terraria_multiplayer.
3. Jalankan: npm install
4. Jalankan: npm start
5. Buka http://localhost:3000 di browser.
6. Masukkan nama dan room, lalu klik Masuk room.

BERMAIN BERSAMA TEMAN:
- Semua pemain harus membuka server yang sama dan memasukkan nama room yang sama.
- Untuk teman yang berada di jaringan Wi-Fi yang sama, host dapat mencari IP lokal komputernya lalu teman membuka http://IP-LOKAL:3000. Firewall harus mengizinkan port 3000.
- Untuk bermain melalui internet, deploy folder ini ke hosting Node.js yang mendukung WebSocket/Socket.IO (contohnya Render, Railway, atau VPS), lalu bagikan URL server. Hosting dan konfigurasi jaringan tidak disertakan otomatis dalam ZIP ini.

BATASAN PROTOTIPE:
- Posisi pemain dan perubahan blok disinkronkan real-time dalam room.
- Dunia/room disimpan di memori server dan hilang saat server dimulai ulang atau room kosong.
- Inventory/crafting/enemies dari versi sebelumnya belum disinkronkan antar pemain pada prototipe multiplayer ini.
- Ini demo dasar, belum memiliki sistem akun, anti-cheat, validasi gameplay penuh, atau database persisten.
